package nl.hva.miw.datastructuren.tentamen.opdracht3.command;

public interface Command {

	public void doCommand();

	public void undoCommand();
}
