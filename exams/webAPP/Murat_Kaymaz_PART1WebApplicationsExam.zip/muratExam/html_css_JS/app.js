document.getElementById("button").onclick = function changeHeader() {


    document.getElementById("h1").innerHTML = "FIJNE FEEST DAGEN AND GLUKKIG NIEUWJAAR!";

}


///bonus part

document.getElementById("buttonBonus").onclick = function changeAll() {
    var pTags = document.querySelectorAll("p");

    for (let p of pTags) {
        p.innerHTML = "FIJNE FEEST DAGEN AND GLUKKIG NIEUWJAAR!"
    }

    document.getElementById("h1").innerHTML = "FIJNE FEEST DAGEN AND GLUKKIG NIEUWJAAR!";
    document.getElementById("h3").innerHTML = "FIJNE FEEST DAGEN AND GLUKKIG NIEUWJAAR!";

}