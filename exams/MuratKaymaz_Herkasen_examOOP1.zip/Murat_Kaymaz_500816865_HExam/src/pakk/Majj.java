package pakk;

public class Majj {
public static void main(String[] args) {
	System.out.println("Workkkk");
}
}
