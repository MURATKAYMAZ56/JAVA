document.getElementById("logo").onclick = function allTux() {
    var paragraphs = document.getElementsByTagName("P");
    for(p of paragraphs){
        p.innerHTML= "<b>Tux everywhere!</b>"
    }
}
