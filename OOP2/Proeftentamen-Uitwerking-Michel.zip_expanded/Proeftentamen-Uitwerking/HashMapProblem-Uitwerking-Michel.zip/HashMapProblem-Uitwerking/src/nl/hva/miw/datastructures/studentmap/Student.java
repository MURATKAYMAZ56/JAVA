package nl.hva.miw.datastructures.studentmap;

public class Student {
	private String name;
	private int id;

	public Student(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public int getId() {
		return id;
	}

	/**
	 * WARNING: the hashCode() needs to be consistent with equals().
	 * 
	 * If s1.equals(s2) == true, then s1.hashCode() == s2.hashCode() must be true too!
	 */
	@Override
	public int hashCode() {
		// ANSWER: OLD CODE WAS;
		// return name.hashcode() + id;
		// This means that it violates the requirement that hashCode() is consistent with equals().
		
		// Simple fix (maybe not the best hashCode() function): hash code only depends on id.
		return id;

	}

	/**
	 * Students are equal if they match on id. Name is ignored.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return (id == other.id);
	}
}